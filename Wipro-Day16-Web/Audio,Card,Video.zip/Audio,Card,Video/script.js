// You can add interactive JavaScript here
/*
document.querySelector("form").addEventListener("submit", function (e) {
  e.preventDefault();
  alert("Form submitted successfully!");
});
*/